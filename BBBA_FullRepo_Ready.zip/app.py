
import streamlit as st
import yfinance as yf
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="BBBA Analyzer", layout="wide")

st.title("📊 BBBA - Business & Portfolio Analyzer")
st.markdown("Supports **Global + PSX Stocks**, Buffett Valuation, Portfolio Tracker, Urdu + English.")

ticker = st.text_input("Enter Stock Ticker (e.g., AAPL for Apple, PSX:OGDC for OGDC Pakistan):")

if ticker:
    try:
        data = yf.download(ticker, period="1y")
        st.line_chart(data['Close'])
        
        st.subheader("📈 Stock Data")
        st.write(data.tail())

        fig = px.line(data, x=data.index, y="Close", title=f"{ticker} Stock Price Trend")
        st.plotly_chart(fig, use_container_width=True)

    except Exception as e:
        st.error(f"Error fetching data: {e}")

st.sidebar.header("🌍 Features")
st.sidebar.markdown("- Global + PSX Stocks
- Portfolio Tracker
- Buffett Valuation
- Urdu + English Support")
