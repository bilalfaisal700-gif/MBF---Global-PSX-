# BBBA - Business & Portfolio Analyzer

Supports Global + PSX Stocks, Buffett Valuation, Portfolio Tracker, Urdu + English.